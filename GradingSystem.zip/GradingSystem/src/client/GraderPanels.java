package client;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class GraderPanels {
	private JPanel gpanel1;
	
	public GraderPanels()
	{
		panel1init();
	}
	
	private void panel1init()
	{
		
		gpanel1 = new JPanel(null);
		
		JLabel selectlbl = new JLabel("Select student to grade");
		JLabel projectselectlbl = new JLabel("Select Project");
		JButton gradebtn = new JButton("Grade");
		JButton logoutbtn = new JButton("Logout");
		JTable stutable = new JTable();
		DefaultTableModel dtm = new DefaultTableModel(0, 0);
		String header[] = new String[] { "ID", "Student Name"};
		dtm.setColumnIdentifiers(header);
		stutable.setModel(dtm);
		JScrollPane sp1stud = new JScrollPane(stutable);
		stutable.setPreferredScrollableViewportSize(new Dimension(600,200));
		stutable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		String[] projectString= null;
		@SuppressWarnings("unchecked")
		UserList<Grader> graslist = ((UserList<Grader>) DataStore.getInstance().getUsers("gra"));
		@SuppressWarnings("unchecked")
		UserList<Professor> profslist = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
		Professor gprof = null;
		for(int i=0;i<profslist.size();i++)
		{
			if(profslist.getUserList().get(i).getProf().getName().equals(graslist.getUserList().get(0).getProfesor()))
					{
						gprof = profslist.getUserList().get(i);
					}
		}
		if(gprof.getProjects().size() > 0)
		{
		projectString = new String[gprof.getProjects().size()];
		for(int i=0;i<gprof.getProjects().size();i++)
		{
			projectString[i] = gprof.getProjects().get(i).getTitle();
		}
		}
		
		final Professor profselected = gprof; 
		
		JComboBox<String> projectbox = new JComboBox<String>(projectString);
		@SuppressWarnings("unchecked")
		UserList<Student> tstuds = ((UserList<Student>) DataStore.getInstance().getUsers("stu"));
		if(tstuds!=null)
		{
		for(int i=0;i<tstuds.size();i++)	
			dtm.addRow(new Object[] {stutable.getRowCount(),tstuds.getUserList().get(i).getStudentDetails().getName()});
		}
		
		gradebtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int selectedindex = stutable.getSelectedRow();
				if(selectedindex > -1)
					setPanel2(profselected.getProjects().get(projectbox.getSelectedIndex()),tstuds.getUserList().get(selectedindex).getStudentDetails().getEmail());
			}
		});
		
		
		logoutbtn.setBounds(450,10,100,50);
		projectselectlbl.setBounds(20,30,300,50);
		projectbox.setBounds(40,70,200,30);
		selectlbl.setBounds(20,100,300,50);
		gradebtn.setBounds(330,560,200,50);
        sp1stud.setBounds(10, 140, 680,400);
		
        gpanel1.add(selectlbl);
        gpanel1.add(projectselectlbl);
        gpanel1.add(logoutbtn);
        gpanel1.add(gradebtn);
		gpanel1.add(sp1stud);
		gpanel1.add(projectbox);
	}

	public JPanel getGpanel1() {
		return gpanel1;
	}
	
	
	private void setPanel2(ProjectStatement p,String email)
	{
		FrameSingleton.getInstance().getFrame().remove(gpanel1);
		FrameSingleton.getInstance().getFrame().add(gpanel2init(p,email));
		FrameSingleton.getInstance().getFrame().setVisible(true);
	}
	
	private JPanel gpanel2init(ProjectStatement p,String email)
	{
		JPanel gpanel2 = new JPanel(null);
		
		JButton emailbtn = new JButton("E-mail");
		JButton backbtn = new JButton("Back");
		JTable gradetable = new JTable();
		DefaultTableModel dtm = new DefaultTableModel(0, 0);
		String header[] = new String[] { "ID", "Requirement","Comment","Marks Obtained","Max Marks"};
		dtm.setColumnIdentifiers(header);
		gradetable.setModel(dtm);
		JScrollPane sp1stud = new JScrollPane(gradetable);
		gradetable.setPreferredScrollableViewportSize(new Dimension(600,200));
		gradetable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		for (Map.Entry<String, String> entry : p.getRequirements().entrySet())
		{
			dtm.addRow(new Object[] {gradetable.getRowCount(),entry.getKey(),"","",entry.getValue()});
		}
		
		backbtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				FrameSingleton.getInstance().getFrame().remove(gpanel2);
				FrameSingleton.getInstance().getFrame().add((new GraderPanels()).getGpanel1());
				FrameSingleton.getInstance().getFrame().setVisible(true);
			}
		});
		
		emailbtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String output = "Id           ";
				output = output+"Requirements          ";
				output = output+"Comments          ";
				output = output+"MarksObtained          ";
				output = output+"Max Marks          "+"\n";
				for(int i =0;i<gradetable.getRowCount();i++)
				{
					for(int j=0;j<gradetable.getColumnCount();j++)
					{
						output = output + gradetable.getModel().getValueAt(i, j)+"          ";
					}
					output = output +"\n";
				}
				startemailthread(output,email);
			}
		});
		
		emailbtn.setBounds(20, 10, 200, 50);
		backbtn.setBounds(550,10,100,30);
		sp1stud.setBounds(20, 70, 650, 500);
		
		gpanel2.add(emailbtn);
		gpanel2.add(backbtn);
		gpanel2.add(sp1stud);
		
		return gpanel2;
		
	}
	
	private void startemailthread(String text,String email)
	{
		 new Thread() {
				public void run() {
		        	String[] emails={email};
		        	Mail mail= new Mail();
		    		Pdf pdf = new Pdf();
		    		pdf.createPdf(text);
		    		mail.sendMail(emails, "Grade Report");
		        	
		        }
		    }.start();
	}
	


}
