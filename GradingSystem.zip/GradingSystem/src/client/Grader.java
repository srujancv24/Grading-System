package client;
import java.io.Serializable;

public class Grader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Person grader;
	String profesor;
	
	public Grader(Person g,String p)
	{
		this.grader = g;
		this.profesor = p;
	}

	public Person getGrader() {
		return grader;
	}

	public void setGrader(Person grader) {
		this.grader = grader;
	}

	public String getProfesor() {
		return profesor;
	}

	public void setProfesor(String profesor) {
		this.profesor = profesor;
	}
	
}
