package client;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class UserList<E>  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<E> userList;
	
	public UserList()
	{
		userList = new ArrayList<E>();
	}
	
	public ArrayList<E> getUserList()
	{
		return this.userList;
	}
	
	public void addUser(E e)
	{
		this.userList.add(e);
	}
	
	@SuppressWarnings("unchecked")
	public boolean searchUserbyLoginDetails(String userType,String UserName,String pwd)
	{
		try
		{
		if(userType.equals("pro"))
		{
			ArrayList<Professor> tprofs = (ArrayList<Professor>) this.userList;
			for(int i =0 ;i < tprofs.size();i++)
			{
				if((tprofs.get(i).getProf().getEmail().equals(UserName)) && (tprofs.get(i).getProf().getPwd().equals(pwd)))
				{
					Collections.swap(tprofs, 0, i);
					return true;
				}
			}
		}
		else if(userType.equals("stu"))
		{
			ArrayList<Student> tstuds = (ArrayList<Student>) this.userList;
			for(int i =0 ;i < tstuds.size();i++)
			{
				if((tstuds.get(i).getStudentDetails().getEmail().equals(UserName)) && (tstuds.get(i).getStudentDetails().getPwd().equals(pwd)))
				{
					Collections.swap(tstuds, 0, i);
					return true;
				}
			}
		}
		else if(userType.equals("gra"))
		{
			ArrayList<Grader> tgrads = (ArrayList<Grader>) this.userList;
			for(int i =0 ;i < tgrads.size();i++)
			{
				if((tgrads.get(i).getGrader().getEmail().equals(UserName)) && (tgrads.get(i).getGrader().getPwd().equals(pwd)))
				{
					Collections.swap(tgrads, 0, i);
					return true;
				}
			}
		}
		return false;
		}
		catch(Exception e)
		{
			System.err.println("search user by login details exception: " + e.toString());
			e.printStackTrace();
			return false;
		}
	}
	
	
	public int size()
	{
		return this.userList.size();
	}


}
