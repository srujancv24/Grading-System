package client;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;


public class Professor implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Person prof;
	private ArrayList<ProjectStatement> projects;
	
	public Professor(Person p)
	{
		prof= p;
	}
	
	public Person getProf() {
		return prof;
	}
	public void setProf(Person prof) {
		this.prof = prof;
	}
	public ArrayList<ProjectStatement> getProjects() {
		return projects;
	}
	public void setProjects(ArrayList<ProjectStatement> projects) {
		this.projects = projects;
	}
	
	public void addProject(ProjectStatement p)
	{		
		if(this.projects== null)
			this.projects = new ArrayList<ProjectStatement>();
		this.projects.add(p);
		DataStore.getInstance().dswriteFile("ProfessorList.dat");	
	}
	
	public static String getProjectParagraph(ProjectStatement p)
	{
		int i =0 ;
		String para = "Title:"+"\n"+p.getTitle()+"\n"+"Scope:"+"\n"+ p .getPurpose() + "\n" + "Requirements:";
		for (Map.Entry<String, String> entry : p.getRequirements().entrySet())
		{
			i++;
		    para = para + i+"." +  "("+entry.getValue()+")" + " " + entry.getKey()+"\n";
		}
		
		return para;
	}
	
	public void sendProject(ProjectStatement sendProject,String[] emails, String Subject)
	{
		Mail mail= new Mail();
		Pdf pdf = new Pdf();
		pdf.createPdf(getProjectParagraph(sendProject));
		mail.sendMail(emails, Subject);
	}
}
