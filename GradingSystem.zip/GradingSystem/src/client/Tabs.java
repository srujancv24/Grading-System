package client;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

public class Tabs {
	
	 	final static String LOGINPANEL = "Login";
	    final static String REGPANEL = "Register";
	    final static String NEWPROJECT = "New Project";
	    final static String VIEWPROJECT = "View Project";
	    final static String LOGOUTPANEL = "Logout";
	    final static int extraWindowWidth = 100;
	    private JTabbedPane tabbedPane;
	    private JTabbedPane projtabPane;
	    private JPanel stupanel;
	 
	    public void addComponentToPane(Container pane) {
	        tabbedPane = new JTabbedPane();
	 
	        //Create the "cards".
	        JPanel card1 = new JPanel(null);
	        
	        JLabel welLabel = new JLabel("Welcome");
	        welLabel.setForeground(Color.blue);
	        welLabel.setFont(new Font("Serif", Font.BOLD, 40));
	        JTextField userfield = new JTextField("", 20);
	        JTextField pwdField = new JPasswordField("", 20);
	        String[] userTypeStrings = { "Professor", "Student","Grader"};
			JComboBox<String> userTypebox = new JComboBox<String>(userTypeStrings);
	        card1.add(welLabel);
	        card1.add(userfield);
	        card1.add(pwdField);
	        card1.add(userTypebox);
	        JButton logbutton = new JButton("Login");
	        logbutton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					verifyUser(userfield.getText().trim(),pwdField.getText(),userTypebox.getSelectedItem().toString());
				}
			});
	        card1.add(logbutton);     
	        
	        welLabel.setBounds(250, 30, 600, 50);
	        userfield.setBounds(80, 90, 200, 30);
	        pwdField.setBounds(80, 130, 200, 30);
	        userTypebox.setBounds(80, 170, 200, 30);
	        logbutton.setBounds(290, 300, 100, 30);
			
	 
	        JPanel card2 = regPanel();
	        
	        
	 
	        tabbedPane.addTab(LOGINPANEL, card1);
	        tabbedPane.addTab(REGPANEL, card2);

	        pane.add(tabbedPane,null);
	    }
	    
	    private JPanel regPanel()
		{
			JPanel regPanel = new JPanel();
			regPanel.setLayout(null);

			JLabel reglabel = new JLabel("Register");
			reglabel.setForeground(Color.blue);
			reglabel.setFont(new Font("Serif", Font.BOLD, 40));

			JLabel userlabel = new JLabel("Name:");
			JLabel emaillabel = new JLabel("Email-ID:");
			JLabel pwdlabel = new JLabel("Create Passowrd:");
			JLabel cpwdlabel = new JLabel("Confirm Password:");
			JLabel userTypelabel = new JLabel("User Type:");
			JLabel proflabel = new JLabel("Select Professor:");

			JTextField usertextfield = new JTextField();
			JTextField emailtextfield = new JTextField();
			JPasswordField pwdfield = new JPasswordField();
			JPasswordField cpwdField = new JPasswordField();
			
			String[] userTypeStrings = { "Professor", "Student","Grader"};

			JComboBox<String> userTypeList = new JComboBox<String>(userTypeStrings);
			
			String[] professorString;
			@SuppressWarnings("unchecked")
			UserList<Professor> profslist = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
			professorString = new String[profslist.size()];
			for(int i=0;i<profslist.size();i++)
			{
				professorString[i] = profslist.getUserList().get(i).getProf().getName();
			}
			
			
			JComboBox<String> professorTypebox = new JComboBox<String>(professorString);
			professorTypebox.setVisible(false);
			proflabel.setVisible(false);
			
			
			JLabel regstatuslabel = new JLabel();
			regstatuslabel.setFont(new Font("Serif", Font.BOLD, 40));
			regstatuslabel.setVisible(false);
			
			JButton regbutton = new JButton("Register");
			regbutton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String profname = null;
					if(userTypeList.getSelectedItem().toString().equals("Grader"))
					{
						profname = professorTypebox.getSelectedItem().toString();
					}		
				if(registerUser(usertextfield.getText(),emailtextfield.getText(),new String(pwdfield.getPassword()),userTypeList.getSelectedItem().toString(),profname))
				{
					regstatuslabel.setText("Successful");
					regstatuslabel.setForeground(Color.green);
					regstatuslabel.setVisible(true);
					
					usertextfield.setText("");
		        	emailtextfield.setText("");
		        	pwdfield.setText("");;
		        	cpwdField.setText("");
		        	userTypeList.setSelectedIndex(0);
		        	proflabel.setVisible(false);
		        	professorTypebox.setVisible(false);
				}
				else
				{
					regstatuslabel.setText("Failed");
					regstatuslabel.setForeground(Color.red);
					regstatuslabel.setVisible(true);
				}
				}
			});
			
			
	        ItemListener itemListener = new ItemListener() {
	            public void itemStateChanged(ItemEvent itemEvent) {
	              int state = itemEvent.getStateChange();
	              if(itemEvent.getItem().equals("Grader") && state == ItemEvent.SELECTED)
	              {
	            	  professorTypebox.setVisible(true);
	            	  proflabel.setVisible(true);
	              }
	              else
	              {
	            	  professorTypebox.setVisible(false);
	            	  proflabel.setVisible(false);
	              }
	            }
	          };
	          userTypeList.addItemListener(itemListener);
			
			
			
			reglabel.setBounds(250, 30, 600, 50);
			userlabel.setBounds(80, 90, 200, 30);
			emaillabel.setBounds(80, 130, 200, 30);
			pwdlabel.setBounds(80, 170, 200, 30);
			cpwdlabel.setBounds(80, 210, 200, 30);
			usertextfield.setBounds(300, 90, 200, 30);
			emailtextfield.setBounds(300, 130, 200, 30);
			pwdfield.setBounds(300, 170, 200, 30);
			cpwdField.setBounds(300, 210, 200, 30);
			userTypelabel.setBounds(80,250,200,30);
			userTypeList.setBounds(300,250,200,30);
			proflabel.setBounds(80,290,200,30);
			professorTypebox.setBounds(300,290,200,30);
			regbutton.setBounds(290, 330, 100, 30);
			regstatuslabel.setBounds(290, 370, 600, 50);
			
			
			regPanel.add(reglabel);
			regPanel.add(userlabel);
			regPanel.add(emaillabel);
			regPanel.add(pwdlabel);
			regPanel.add(cpwdlabel);
			regPanel.add(usertextfield);
			regPanel.add(emailtextfield);
			regPanel.add(pwdfield);
			regPanel.add(cpwdField);
			regPanel.add(regbutton);
			regPanel.add(userTypelabel);
			regPanel.add(userTypeList);
			regPanel.add(proflabel);
			regPanel.add(professorTypebox);
			regPanel.add(regstatuslabel);
			
			 ChangeListener changeListener = new ChangeListener() {
			      public void stateChanged(ChangeEvent changeEvent) {
			        JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
			        int index = sourceTabbedPane.getSelectedIndex();
			        if(index == 1)
			        {
			        	usertextfield.setText("");
			        	emailtextfield.setText("");
			        	pwdfield.setText("");;
			        	cpwdField.setText("");
			        	regstatuslabel.setVisible(false);
			        	
			        }
			        
			      }
			    };
			    tabbedPane.addChangeListener(changeListener);
			
			return regPanel;
		}
	    
		private boolean registerUser(String name,String email,String pwd,String userType,String pname)
		{
			try
			{
			boolean registartionstatus = false;
			if(userType.equals("Professor"))
				registartionstatus = DataStore.getInstance().addUser("pro",new Professor(new Person(name,email,pwd,userType)));
			else if(userType.equals("Student"))
				registartionstatus = DataStore.getInstance().addUser("stu",new Student(new Person(name,email,pwd,userType)));
			else if(userType.equals("Grader"))
				registartionstatus = DataStore.getInstance().addUser("gra",new Grader(new Person(name,email,pwd,userType),pname));
			return registartionstatus;
			}
			catch(Exception e)
			{
				System.err.println("Register User Exception: " + e.toString());
				e.printStackTrace();
				return false;
			}
		}
		
		
		@SuppressWarnings("unchecked")
		private void verifyUser(String name,String Pwd,String UserType)
		{
			boolean loginstatus = false;
			if(UserType.equals("Professor"))
			{
				UserList<Professor> tprofs = (UserList<Professor>)DataStore.getInstance().getUsers("pro");
				loginstatus = tprofs.searchUserbyLoginDetails("pro", name, Pwd);
			}
			else if(UserType.equals("Student"))
			{
				UserList<Student> tstus = (UserList<Student>)DataStore.getInstance().getUsers("stu");
				loginstatus = tstus.searchUserbyLoginDetails("stu", name, Pwd);
			}
			else if(UserType.equals("Grader"))
			{
				UserList<Grader> tstus = (UserList<Grader>)DataStore.getInstance().getUsers("gra");
				loginstatus = tstus.searchUserbyLoginDetails("gra", name, Pwd);
			}
			
			if(loginstatus == true)
			{
				FrameSingleton.getInstance().getFrame().remove(tabbedPane);
				if(UserType.equals("Professor"))
				{
				projectsTabbedpane(FrameSingleton.getInstance().getFrame().getContentPane());
				FrameSingleton.getInstance().getFrame().setVisible(true);
				}
				else if(UserType.equals("Student"))
				{
					FrameSingleton.getInstance().getFrame().add(studentPanel());
					FrameSingleton.getInstance().getFrame().setVisible(true);
				}
				else if(UserType.equals("Grader"))
				{
					FrameSingleton.getInstance().getFrame().add((new GraderPanels()).getGpanel1());
					FrameSingleton.getInstance().getFrame().setVisible(true);
				}
			}
			else
			{
				JPanel wrngPanel = new JPanel(null);
				JLabel wellabel = new JLabel("Invalid Login");
				wellabel.setForeground(Color.blue);
		        wellabel.setFont(new Font("Serif", Font.BOLD, 40));
		        JButton relogin = new JButton("Re-Login");
		        wellabel.setBounds(250, 30, 600, 50);
		        relogin.setBounds(130, 130, 200, 30);
		        relogin.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						openrelogin(wrngPanel);
					}
				});
		        wrngPanel.add(wellabel);
		        wrngPanel.add(relogin);
				FrameSingleton.getInstance().getFrame().remove(tabbedPane);
				FrameSingleton.getInstance().getFrame().getContentPane().add(wrngPanel);
				FrameSingleton.getInstance().getFrame().setVisible(true);
			}
			
		}
		
		private JPanel studentPanel()
		{
			stupanel = new JPanel(null);
			
			JLabel reglabel = new JLabel("Thank you for registering");
			reglabel.setForeground(Color.blue);
			reglabel.setFont(new Font("Serif", Font.BOLD, 40));
			
			JButton logoutbtn = new JButton("Logout");
			logoutbtn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					logoutWindow(stupanel);
				}
			});
			
			
			reglabel.setBounds(250, 30, 600, 50);
			logoutbtn.setBounds(250,80,100,50);
			
			stupanel.add(reglabel);
			stupanel.add(logoutbtn);
			
			return stupanel;
			
		}
		
		private void logoutWindow(Container c)
		{
			FrameSingleton.getInstance().getFrame().remove(c);
			addComponentToPane(FrameSingleton.getInstance().getFrame().getContentPane());
			FrameSingleton.getInstance().getFrame().setVisible(true);
		}
		private void openrelogin(JPanel wrngPanel)
		{
			FrameSingleton.getInstance().getFrame().remove(wrngPanel);
			this.addComponentToPane(FrameSingleton.getInstance().getFrame().getContentPane());
			FrameSingleton.getInstance().getFrame().setVisible(true);
		}
		
		private void projectsTabbedpane(Container pane)
		{
			projtabPane = new JTabbedPane();
			 
	        //Create the "cards".
			JPanel card1 = newProjectGUI();
	        JPanel card2 = viewProjectGUI();
	        
	        JPanel card3 = new JPanel(null);
	        
	        JButton lgbtn = new JButton("Logout");
	        lgbtn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					logoutWindow(projtabPane);
				}
			});
	        card3.add(lgbtn);

	        lgbtn.setBounds(200,50,100,50);
	        	 
	        projtabPane.addTab(NEWPROJECT, card1);
	        projtabPane.addTab(VIEWPROJECT, card2);
	        projtabPane.addTab(LOGOUTPANEL, card3);
	 
	        pane.add(projtabPane,null);
		}
		
		@SuppressWarnings("unchecked")
		private JPanel viewProjectGUI()
		{
			JPanel card2 = new JPanel(null);
			
			JLabel wel1Label = new JLabel("VIEW PROJECTS");
	        wel1Label.setForeground(Color.blue);
	        wel1Label.setFont(new Font("Serif", Font.BOLD, 40));
	        
	        JButton emailbutton = new JButton("E-Mail Project");
	        
	        JTable reqtable = new JTable();
			DefaultTableModel dtm = new DefaultTableModel(0, 0);
			String header[] = new String[] { "ID", "Project Title"};
			dtm.setColumnIdentifiers(header);
			reqtable.setModel(dtm);
			JScrollPane sp1stud = new JScrollPane(reqtable);
			reqtable.setPreferredScrollableViewportSize(new Dimension(600,200));
			reqtable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			
			
			UserList<Professor> tprofs = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
			ArrayList<ProjectStatement> tprojs = tprofs.getUserList().get(0).getProjects();
			if(tprojs!=null)
			{
			for(int i=0;i<tprojs.size();i++)	
				dtm.addRow(new Object[] {reqtable.getRowCount(),tprojs.get(i).getTitle()});
			}
			
			

			ChangeListener changeListener = new ChangeListener() {
			      public void stateChanged(ChangeEvent changeEvent) {
			        JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
			        int index = sourceTabbedPane.getSelectedIndex();
			        if(index == 1)
			        {
			        	UserList<Professor> t2profs = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
						ArrayList<ProjectStatement> t2projs = t2profs.getUserList().get(0).getProjects();
			        	dtm.setRowCount(0);
			        	for(int i=0;i<t2projs.size();i++)	
							dtm.addRow(new Object[] {reqtable.getRowCount(),t2projs.get(i).getTitle()});
			        	dtm.fireTableDataChanged();	
			        }
			        
			      }
			    };
			    projtabPane.addChangeListener(changeListener);
			
			emailbutton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					int selectedindex = reqtable.getSelectedRow();
					startemailthread(selectedindex);
				}
			});
			
	        wel1Label.setBounds(250, 30, 600, 50);
	        emailbutton.setBounds(20,70,200,50);
	        sp1stud.setBounds(10, 300, 680,260);
	        
	        card2.add(wel1Label);
	        card2.add(emailbutton);
	        card2.add(sp1stud);
	        
			return card2;
		}
		private void startemailthread(int selectedindex)
		{
			 new Thread() {
			        @SuppressWarnings("unchecked")
					public void run() {
			        	String[] emails={};
			        	UserList<Student> tstuds = (UserList<Student>)DataStore.getInstance().getUsers("stu");
			        	emails = new String[tstuds.size()];
			        	for(int i=0;i<tstuds.size();i++)
			        	{
			        		emails[i] = tstuds.getUserList().get(i).getStudentDetails().getEmail();
			        	}
						UserList<Professor> tprofs = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
						tprofs.getUserList().get(0).sendProject(tprofs.getUserList().get(0).getProjects().get(selectedindex), emails, "Project");
			        }
			    }.start();
		}
		private JPanel newProjectGUI()
		{
			JPanel card1 = new JPanel(null);
			JLabel welLabel = new JLabel("NEW PROJECT");
	        welLabel.setForeground(Color.blue);
	        welLabel.setFont(new Font("Serif", Font.BOLD, 40));
	        
	        
	        
	        JLabel objlabel = new JLabel("Title");
	        objlabel.setFont(new Font("Serif",Font.PLAIN,20));
			JLabel scopelabel = new JLabel("Objective");
			scopelabel.setFont(new Font("Serif",Font.PLAIN,20));
			JLabel re1label = new JLabel("Reqs & Marks");
			re1label.setFont(new Font("Serif",Font.PLAIN,20));
			
			JTextField objtextfield = new JTextField();
			JTextArea scopetextfield = new JTextArea();
			JTextField req1textfield = new JTextField();
			JTextField req1mtextfield = new JTextField();
			
			
			JTable reqtable = new JTable();
			DefaultTableModel dtm = new DefaultTableModel(0, 0);
			String header[] = new String[] { "ID", "Requirement","Marks" };
			dtm.setColumnIdentifiers(header);
			reqtable.setModel(dtm);
			JScrollPane sp1stud = new JScrollPane(reqtable);
			reqtable.setPreferredScrollableViewportSize(new Dimension(600,200));
			reqtable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

			
			JButton createButton = new JButton("Create Project");
			JButton addRefbutton = new JButton("Add");
			
			
			
			createButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					Map<String, String> reqs = new HashMap<String, String>();
					for (int i = 0 ; i <  dtm.getRowCount() ; i++)
					{
						reqs.put(dtm.getValueAt(i, 1).toString(),dtm.getValueAt(i,2).toString());
					}
					newProject(objtextfield.getText(),scopetextfield.getText(),reqs);
					objtextfield.setText("");
					scopetextfield.setText("");
					dtm.setRowCount(0);
					dtm.fireTableDataChanged();
				}
			});
			
		
			addRefbutton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					dtm.addRow(new Object[] {reqtable.getRowCount(), req1textfield.getText(),req1mtextfield.getText()});
					dtm.fireTableDataChanged();
					req1textfield.setText("");
					req1mtextfield.setText("");
				}
			});
			
			

			welLabel.setBounds(250, 30, 600, 50);
			objlabel.setBounds(20, 90, 600, 50);
			scopelabel.setBounds(20,130, 200, 30);
			re1label.setBounds(20, 250, 200, 30);
			objtextfield.setBounds(150, 90, 200, 30);
			scopetextfield.setBounds(150, 130, 500, 100);
			req1textfield.setBounds(150, 250, 200, 30);
			req1mtextfield.setBounds(520, 250, 30, 30);
			addRefbutton.setBounds(580, 250, 100,30);
			createButton.setBounds(290, 630,150, 30);
			sp1stud.setBounds(10, 300, 680,260);
			

	
	        card1.add(welLabel);
	        card1.add(objlabel);
	        card1.add(scopelabel);
	        card1.add(re1label);
	        card1.add(objtextfield);
	        card1.add(scopetextfield);
	        card1.add(req1textfield);
	        card1.add(createButton);
	        card1.add(req1mtextfield);
	        card1.add(sp1stud);
	        card1.add(addRefbutton);
	        
	        return card1;
	        
		}
		
		private void newProject(String Obj,String scp,Map<String, String> reqs)
		{
			
			@SuppressWarnings("unchecked")
			UserList<Professor> tprofs = ((UserList<Professor>) DataStore.getInstance().getUsers("pro"));
			tprofs.getUserList().get(0).addProject(new ProjectStatement(Obj,scp,reqs));
		}
		
}


