package client;
import java.io.Serializable;

public class Student implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Person studentDetails;

	public Student(Person student)
	{
		this.studentDetails = student;
	}
	public Person getStudentDetails() {
		return studentDetails;
	}

	public void setStudentDetails(Person studentDetails) {
		this.studentDetails = studentDetails;
	}
}
