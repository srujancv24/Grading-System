package client;
public class DataStore {

	private UserList<Professor> profs;
	private UserList<Student> students;
	private UserList<Grader> graders;
	private static DataStore instance = null;

	public static DataStore getInstance() {
		if (instance == null) {
			instance = new DataStore();
			instance.init();
		}
		return instance;
	}

	@SuppressWarnings("unchecked")
	private void init() {
		try
		{
			profs = (UserList<Professor>) RegistrySingleton.getInstance().getStub().readFile("ProfessorList.dat");
			if(profs == null)
				profs = new UserList<Professor>();
			students = (UserList<Student>) RegistrySingleton.getInstance().getStub().readFile("StudentList.dat");
			if(students == null)
				students = new UserList<Student>();
			graders = (UserList<Grader>) RegistrySingleton.getInstance().getStub().readFile("GraderList.dat");
			if(graders == null)
				graders = new UserList<Grader>();
		}
		catch(Exception e)
		{
			System.err.println("init exception: " + e.toString());
			e.printStackTrace();
		}
	}
	
	public Object getUsers(String userType) {
		try
		{
			if (userType.equals("pro"))
				return profs;
			else if(userType.equals("stu"))
				return students;
			else if(userType.equals("gra"))
				return graders;
			return null;
		}
		catch(Exception e)
		{
			System.err.println("getUsers exception: " + e.toString());
			e.printStackTrace();
			return null;
		}
	}

	public boolean addUser(String userType, Object user) {
		
		try
		{
		boolean addstatus = false;
			if (userType.equals("pro")) {
				this.profs.addUser((Professor) user);
				addstatus = dswriteFile("ProfessorList.dat");
			}
			else if(userType.equals("stu")){
				this.students.addUser((Student) user);
				addstatus = dswriteFile("StudentList.dat");
			}
			else if(userType.equals("gra")){
				this.graders.addUser((Grader) user);
				addstatus = dswriteFile("GraderList.dat");
			}
			
			return addstatus;
		}
		catch(Exception e)
		{
			System.err.println("Add user exception: " + e.toString());
			e.printStackTrace();
			return false;
		}
	}

	public boolean dswriteFile(String fileName)
	{
		try
		{
			if(fileName.equals("ProfessorList.dat"))
				RegistrySingleton.getInstance().getStub().writeFile(this.profs,fileName);
			else if(fileName.equals("StudentList.dat"))
				RegistrySingleton.getInstance().getStub().writeFile(this.students,fileName);
			else if(fileName.equals("GraderList.dat"))
				RegistrySingleton.getInstance().getStub().writeFile(this.graders,fileName);
			return true;
		}
		catch(Exception e)
		{
			System.err.println("Write File exception: " + e.toString());
			e.printStackTrace();
			return false;
		}
	}
	
	

}
