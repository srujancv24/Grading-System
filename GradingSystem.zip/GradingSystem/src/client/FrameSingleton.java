package client;
import javax.swing.JFrame;

public class FrameSingleton {

	private JFrame mainFrame;
	private static FrameSingleton instance= null;
	
	protected FrameSingleton() {
		// Exists only to defeat instantiation.
	}

	public static FrameSingleton getInstance() {
		if (instance == null) {
			instance = new FrameSingleton();
			instance.init();
		}
		return instance;
	}
	
	private void init()
	{
		  mainFrame = new JFrame("Grading System");
		  mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  mainFrame.pack();
		  mainFrame.setSize(750,750);
	}
	
	public JFrame getFrame()
	{
		return instance.mainFrame;
	}
	
}
