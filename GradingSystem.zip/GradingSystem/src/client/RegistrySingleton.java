package client;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import server.RemoteInterface;

public class RegistrySingleton {

	private Registry registry;
	private RemoteInterface stub;
	private static RegistrySingleton instance = null;

	protected RegistrySingleton() {
		// Exists only to defeat instantiation.
	}

	public static RegistrySingleton getInstance() {
		if (instance == null) {
			instance = new RegistrySingleton();
			instance.init();
		}
		return instance;
	}
	private void init()
	{
		try{
			registry = LocateRegistry.getRegistry(null);
			stub = (RemoteInterface) registry.lookup("RemoteInterface");
			}catch(Exception e)
			{
				System.out.println("Client Exception: "+ e.toString());
				e.printStackTrace();
			}
	}
	
	public RemoteInterface getStub()
	{
		return stub;
	}
}
