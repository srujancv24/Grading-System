package client;
import java.io.Serializable;
import java.util.Map;

public class ProjectStatement implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String Title;
	private String purpose;
	private Map<String,String> requirements;
	
	public ProjectStatement(String Title,String purpose,Map<String,String> requirements)
	{
		this.Title = Title;
		this.purpose = purpose;
		this.requirements = requirements;
	}
	
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public Map<String,String> getRequirements() {
		return requirements;
	}
	public void setRequirements(Map<String,String> requirements) {
		this.requirements = requirements;
	}

	public void saveProject(String tit,String pur,Map<String,String> req)
	{
		this.Title = tit;
		this.purpose = pur;
		this.requirements = req;
		
	}
}
