package server;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RemoteInterface  extends Remote{

	public void writeFile(Object userList,String fileName) throws RemoteException;
	public Object readFile(String fileName) throws RemoteException;
}
