package server;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
public class GradingServer implements RemoteInterface{
	
	public GradingServer(){
		
	}
	
	public void writeFile(Object userList,String fileName) throws RemoteException
	{
		try{
			FileOutputStream fileOut = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(userList);
			out.close();
        	fileOut.close();
		}
		catch (EOFException e) {
			} catch (Exception ex) {
				System.out.println("Server write file Exception");
			    ex.printStackTrace();
			} 
	}
	
	public Object readFile(String fileName) {
		Object o=null;
		try {
			FileInputStream inStream = new FileInputStream(fileName);
			ObjectInputStream oiStream = new ObjectInputStream(inStream);
			o=oiStream.readObject();
			oiStream.close();
        	inStream.close();
		}catch (EOFException e) {
		} catch (Exception ex) {
			System.out.println("Server Read file Exception");
		    ex.printStackTrace();
		} 
		return o;
	} 
	
	public static void main(String args[])
	{
		try{
			GradingServer serobj = new GradingServer();
			RemoteInterface stub = (RemoteInterface) UnicastRemoteObject.exportObject(serobj,0);
			
			Registry registry = LocateRegistry.getRegistry();
			registry.bind("RemoteInterface", stub);
			System.err.println("Server ready");
		}
		catch(Exception e){
			System.err.println("Server Exception: "+ e.toString());
			e.printStackTrace();
		}
	}

}
